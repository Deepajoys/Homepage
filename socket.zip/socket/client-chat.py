import socket
client_socket = socket.socket()
port = 12345
client_socket.connect(('127.0.0.1',port))
#recieve connection message from server
recv_msg = client_socket.recv(1024)
print(recv_msg)
#send user details to server
send_msg = input(b"Enter your user name(prefix with #):")
dec_msg=send_msg.encode()
client_socket.send(dec_msg)
#receive and send message from/to different user/s
while True:
    recv_msg = client_socket.recv(1024)
    print (recv_msg)
    send_msg = input(b"Send your message in format [@user:message] ")
    dec_msg=send_msg.encode()
    if dec_msg == b'exit':
        break;
    else:
        client_socket.send(dec_msg)
